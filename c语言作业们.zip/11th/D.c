#include<stdio.h>
#include<string.h>
int main(){
    char a[15];
    int b;
    scanf("%s %d",a,&b);
    if(b>strlen(a)){
        printf("error");
    }
    else printf("%c",a[b-1]);
}