#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<math.h>
int main(){
    char a[1000];
    int c,d;
    char e,f;
    int flag=1;
    while(gets(a)){
        if(strlen(a)==1){
            puts("Yes.");
            continue;
        }
        for(int i=0;i<strlen(a);i++){
            a[i]=tolower(a[i]);
        }
        c=-1;d=strlen(a);
        do{
            c++;d--;
            for(;c<=d;c++){
                if ((a[c]>=97&&a[c]<=122)||(a[c]>=48&&a[c]<=57)){
                    e=a[c];
                    break;
                }
            }
            for(;d>=c;d--){
                if ((a[d]>=97&&a[d]<=122)||(a[d]>=48&&a[d]<=57)){
                    f=a[d];
                    break;
                }
            }
            if (e!=f){
                flag=0;
            }
            
        }
        while(c-d!=0&&d-c!=1&&c-d!=1);
        if(flag){
            puts("Yes.");
        }
        else puts("No.");
        flag=1;
    }
}