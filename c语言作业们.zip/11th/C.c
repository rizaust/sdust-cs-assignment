#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char max[1010];
char min[1010];
char tmp[1010];
int flag = 1;
int main() {
    int post = 0, posx = 0, posn = 0;
    gets(max);
    strcpy(min, max);
    while (gets(tmp)) {
        for (post = 0; post < strlen(tmp); post++) {
            if (tmp[post] != '0') {
                flag = 0;
                break;
            }
        }
        if(flag){
            post--;
        }
        flag=1;
        for (posx = 0; posx < strlen(max); posx++) {
            if (max[posx] != '0') {
                flag = 0;
                break;
            }
        }
        if(flag){
            posx--;
        }
        flag=1;
        for (posn = 0; posn < strlen(min); posn++) {
            if (min[posn] != '0') {
                flag = 0;
                break;
            }
        }
        if(flag){
            posn--;
        }
        flag=1;
        if (strlen(&tmp[post]) > strlen(&max[posx])) {
            strcpy(max, &tmp[post]);
        } else if (strlen(&tmp[post]) == strlen(&max[posx])) {
            if (strcmp(&tmp[post], &max[posx]) > 0) {
                strcpy(max, &tmp[post]);
            }
        }
        if (strlen(&tmp[post]) < strlen(&min[posn])) {
            strcpy(min, &tmp[post]);
        } else if (strlen(&tmp[post]) == strlen(&min[posn])) {
            if (strcmp(&tmp[post], &min[posn]) < 0) {
                strcpy(min, &tmp[post]);
            }
        }
    }
    for (posx = 0; posx < strlen(max); posx++) {
            if (max[posx] != '0') {
                flag = 0;
                break;
            }
        }
        if(flag){
            posx--;
        }
        flag=1;
        for (posn = 0; posn < strlen(min); posn++) {
            if (min[posn] != '0') {
                flag = 0;
                break;
            }
        }
        if(flag){
            posn--;
        }
        flag=1;
    printf("The maximum value is : %s\n", &max[posx]);
    printf("The minimum value is : %s", &min[posn]);
}