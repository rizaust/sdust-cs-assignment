#include <stdio.h>
#include<string.h>
int main() {
    char a[10];
    char b[10];
    int time = 0;
    scanf("%s", a);
    while (~scanf("%s", b)) {
        if (strcmp(a, b) == 0 && time <5) {
            puts("Welcome!");
            return 0;
        }
        else if(time<5){
            puts("Wrong!");
        }
        else puts("Out of limited!");
        time++;
    }
}