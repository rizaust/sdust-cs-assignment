#include<stdio.h>
int main(){
	int a;
	int b;
	scanf("%d %d",&a,&b);
	printf("Octal Decimal Hexadecimal\n");
	printf("%-5o %-4d    %-5x\n",a,a,a);
	printf("%-5o %-4d    %-5x\n",b,b,b);
	return 0;
} 