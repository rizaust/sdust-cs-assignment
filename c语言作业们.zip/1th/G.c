#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main(){
	int a;
	scanf("%d\n",&a);
	double b;
	scanf("%lf",&b);
	a=abs(a);
	b=fabs(b);
	printf("%d\n%g",a,b);
	return 0;
}
