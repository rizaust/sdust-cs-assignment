#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
	double a=1;
	double b=5;
	double c;
	c=a/b;
	printf("%.25lf",c);
} 
