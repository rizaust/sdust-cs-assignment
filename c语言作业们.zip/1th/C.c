#include<stdio.h>
int main(){
	int a;
	scanf("%d",&a);
	a%2?printf("odd"):printf("even");
}
