#include<stdio.h>
int main(){
	int a;
	int b;
	
	scanf("%d",&a);b=a;
	printf("  a   : %d\n",a);
	printf("--a   : %d\n",--a);
	a=b;
	printf("  a-- : %d\n",a--);a=b;
	printf("  a++ : %d\n",a++);a=b;
	printf("++a   : %d",++a);a=b;
	return 0;
}
