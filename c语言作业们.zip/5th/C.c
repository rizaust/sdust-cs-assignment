#include<stdio.h>
int main(){
    int max=-2147483648;
    int a;
    int num=1;
    int nums=1;
    while(~scanf("%d",&a)){
        if(a>max){
            max=a;
            nums=num;
        }
        num++;
    }
    printf("max = %d, order = %d.",max,nums);
}