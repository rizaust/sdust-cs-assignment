#include <stdio.h>
int main() {
    double a, b;
    scanf("%lf %lf", &a, &b);
    a = a * 3.1415926535 / 180;
    double tmp = 1;
    double ans = 0;
    for (int i = 1; i < (2 * b + 1); i += 2) {
        ans += tmp;
        tmp = tmp * (-1) * a * a / i / (i + 1);
    }
    printf("%.6lf", ans);
}