#include <stdio.h>
int main() {
    int a;
    int b, c, d, e;
    while (~scanf("%d",&a)) {
        for (int i = a + 1;; i++) {
            b = i % 10;
            c = (i / 10) % 10;
            d = (i / 100) % 10;
            e = (i / 1000) % 10;
            if(b!=c&&b!=d&&b!=e&&c!=d&&c!=e&&d!=e){
                printf("%d\n",i);
                break;
            }
        }
    }
}