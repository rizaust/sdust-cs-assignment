#include <stdio.h>
int main() {
    int a;
    while(scanf("%d",&a),a!=0){
        printf("%d",a);
        if(a%10==1){
            printf("st\n");
        }
        else if(a%10==2){
            printf("nd\n");
        }
        else if(a%10==3){
            printf("rd\n");
        }
        else{
            printf("th\n");
        }
    }
}