#include <math.h>
#include <stdio.h>
#include <stdlib.h>
double max(double a, double b) {
    if (a == -0) {
        a = 0;
    }
    if (b == -0) {
        b = 0;
    }
    if (a > b)
        return a;
    else
        return b;
}
double min(double a, double b) {
    if (a == -0) {
        a = 0;
    }
    if (b == -0) {
        b = 0;
    }
    if (a > b)
        return b;
    else
        return a;
}
int main() {
    // freopen("1.txt","r",stdin);
    // freopen("2.txt","w",stdout);
    double a, b, c;
    double at, bt, ct;
    double delta;
    int num = 1;
    double ans1, ans2;
    int flag = 1;
    while (scanf("%lf", &a)) {
        if (a == 0) return 0;
        if(flag){
            flag=0;
        }
        else{
            printf("\n\n");
        }
        scanf("%lf %lf", &b, &c);
        printf("Case %d :\n", num);
        num++;
        if (a > 0) {
            if (fabs(a) - 1 < 0.00001)
                printf("x^2");
            else
                printf("%gx^2", a);
            if (b > 0.99999 && b < 1.00001)
                printf(" + x");
            else if (b > -1.00001 && b < -0.99999)
                printf(" - x");
            else if (b < 0)
                printf(" - %gx", -b);
            else if (b == 0)
                printf("");
            else
                printf(" + %gx", b);
            if (c == 0) {
                printf(" = 0\n");
            } else if (c > 0) {
                printf(" + %g = 0\n", c);
            } else
                printf(" - %g = 0\n", -c);
        } else {
            at = -a;
            bt = -b;
            ct = -c;
            if (fabs(at) - 1 < 0.0001)
                printf("x^2");
            else
                printf("%gx^2", at);
            if (bt > 0.9999 && bt < 1.00001)
                printf(" + x");
            else if (bt > -1.00001 && bt < -0.99999)
                printf(" - x");
            else if (bt < 0)
                printf(" - %gx", -bt);
            else if (bt == 0) {
                printf("");
            } else
                printf(" + %gx", bt);
            if (ct == 0) {
                printf(" = 0\n");
            } else if (ct > 0) {
                printf(" + %g = 0\n", ct);
            } else
                printf(" - %g = 0\n", -ct);
        }
        delta = b * b - 4 * a * c;
        if (delta > -0.00001 && delta < 0.00001) {
            ans1 = (-b) / (2 * a);
            printf("only one real root : %g", max(ans1, ans1));
        } else if (delta > 0) {
            ans1 = ((-b) + sqrt(delta)) / (2 * a);
            ans2 = ((-b) - sqrt(delta)) / (2 * a);
            printf("two real roots : %g, %g", min(ans1, ans2),
                   max(ans1, ans2));
        } else {
            ans1 = (-b) / (2 * a);
            ans2 = sqrt(-delta) / (2 * a);
            ans2=fabs(ans2);
            if (ans1 < 0.00001 && ans1 > -0.0001) {
                if ((ans2 < 1.0001 && ans2 > 0.9999) ||
                    (ans2 > -1.0001 && ans2 < -0.9999)) {
                    printf("two imaginary roots : i, -i");
                } else {
                    printf("two imaginary roots : %gi, -%gi", ans2, ans2);
                }
            } else {
                if ((ans2 < 1.0001 && ans2 > 0.99999) ||
                    (ans2 > -1.0001 && ans2 < -0.9999)) {
                    printf("two imaginary roots : %g+i, %g-i", ans1, ans1);
                } else {
                    printf("two imaginary roots : %g+%gi, %g-%gi", ans1, ans2,
                           ans1, ans2);
                }
            }
        }
    }
}
