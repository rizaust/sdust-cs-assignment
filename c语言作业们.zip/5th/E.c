#include <stdio.h>
int main() {
    int a;
    scanf("%d", &a);
    int tmp;
    while (~scanf("%d", &a)) {
        tmp = tmp + a;
    }
    if (tmp >= 0) {
        printf("No");
    } else
        printf("Yes");
}