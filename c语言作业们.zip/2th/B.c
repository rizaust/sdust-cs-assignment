#include <stdio.h>
int main() {
    int a, b;
    char c;
    int ans;
    scanf("%d %c %d =", &a, &c, &b);
    c=='+'? printf("%d %c %d = %d",a,c,b,a+b):printf("%d %c %d = %d",a,c,b,a-b);
    return 0;
}