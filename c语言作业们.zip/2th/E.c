#include<stdio.h>
int main(){
    double a,b,c;
    double d,e;
    scanf("%lf %lf %lf\n",&a,&b,&c);
    scanf("%lf\n",&d);
    scanf("%lf",&e);
    printf("%.2lf %.2lf %.2lf\n",a*d/100,b*d/100,c*d/100);
    printf("%.2lf %.2lf %.2lf",e/a*100,e/b*100,e/c*100);
    return 0;
}