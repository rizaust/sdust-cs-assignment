#include <stdio.h>
int main() {
    int a, b, c;
    scanf("(0%d)%d-%d",&a,&b,&c);
    printf("0086%d%d%d",a,b,c);
    return 0;
}