#include <stdio.h>
int main() {
    int a;
    scanf("%d", &a);
    a=100-a;
    printf("$20 bills: %d\n",a/20);
    a=a%20;
    printf("$10 bills: %d\n",a/10);
    a=a%10;
    printf(" $5 bills: %d\n",a/5);
    a=a%5;
    printf(" $1 bills: %d",a);
    return 0;
}