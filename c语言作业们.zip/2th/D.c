#include<stdio.h>
int main(){
    printf("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
}