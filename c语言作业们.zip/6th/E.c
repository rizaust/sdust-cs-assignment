#include <stdio.h>
int main() {
    int c;
    scanf("%d", &c);
    if(c==7) c=0;
    printf("Sun Mon Tue Wen Thu Fri Sat\n");
    int num = 0;
    for (int i = 0; i < c; i++) {
        printf("    ");
        num++;
    }
    for (int i = 1; i <= 30; i++) {
        num++;
        printf("%3d", i);
        if (num == 7) {
            printf("\n");
            num = 0;
        } else if (i == 30)
            printf("");
        else
            printf(" ");
    }
}