#include<stdio.h>
int main(){
    int a,b;
    int ans=0;
    int num;
    int flag=1;
    scanf("%d",&b);
    for(int j=0;j<b;j++){
        scanf("%d",&a);
        for(int i=0;i<a;i++){
            scanf("%d",&num);
            ans+=num;
        }
        if(flag){
            printf("%d",ans);
            flag=0;
        }
        else printf("\n\n%d",ans);
        ans=0;
    }
}