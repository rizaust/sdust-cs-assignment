#include<stdio.h>
int main(){
    int a;
    int ans=0;
    int num;
    while(scanf("%d",&a),a!=0){
        for(int i=0;i<a;i++){
            scanf("%d",&num);
            ans+=num;
        }
        printf("%d\n",ans);
        ans=0;
    }
}