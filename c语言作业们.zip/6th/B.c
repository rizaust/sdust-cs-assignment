#include<stdio.h>
int main(){
    int a,b;
    int ans=0;
    int num;
    scanf("%d",&b);
    for(int j=0;j<b;j++){
        scanf("%d",&a);
        for(int i=0;i<a;i++){
            scanf("%d",&num);
            ans+=num;
        }
        printf("%d\n",ans);
        ans=0;
    }
}