#include<stdio.h>
#define ull unsigned long long
int main(){
    ull a;
    ull ans=0;
    scanf("%llu",&a);
    if (a%2==0){
        printf("%llu",(a+1)*(a/2));
    }
    else 
        printf("%llu",a*(a/2+1));
    return 0;
}