#include<stdio.h>
int main(){
    int a,b;
    scanf("%d:%d",&a,&b);
    if(a==0)
        printf("12:%02d a.m.",b);
    else if(a<12)
        printf("%02d:%02d a.m.",a,b);
    else if(a==12)
        printf("12:%02d p.m.",b);
    else if(a<=24)
        printf("%02d:%02d p.m.",a-12,b);
    return 0;
}