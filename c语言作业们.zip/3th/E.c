#include<stdio.h>
int main(){
    int a,tmp,ground=0,sky=0;
    scanf("%d",&a);
    scanf("%d",&tmp);
    sky=tmp;ground=tmp;
    for(int i=1;i<a;i++){
        scanf("%d",&tmp);
        if(tmp<ground){
            ground=tmp;
        }
        if(tmp>sky){
            sky=tmp;
        }
    }
    printf("The maximum number is %d.\nThe minimum number is %d.",sky,ground);
    return 0;
}