#include<stdio.h>
int main(){
    int a;
    scanf("%d",&a);
    if(a*a%100000000==a||a*a%10000000==a||a*a%1000000==a||a*a%100000==a||a*a%10000==a||a*a%1000==a||a*a%100==a||a*a%10==a||a==1){
        puts("YES");
    }
    else puts("NO");
    return 0;
}