#include <stdio.h>
int main() {
    int a;
    while (~scanf("%d", &a)) {
        if (a > 100 || a < 0)
            puts("Error");
        else if (a >= 90) {
            puts("Excellent");
        } else if (a >= 80) {
            puts("Good");
        } else if (a >= 70) {
            puts("Average");
        } else if (a >= 60) {
            puts("Pass");
        } else
            puts("Failing");
    }
    return 0;
}