#include <stdio.h>
int main() {
    int a = 0;
    char b;
    int c;
    scanf("%d", &c);
    getchar();
    for(int i=0;i<c;i++){
        while(b=getchar(),b!='\n'&& b!=EOF){
            a=a+(b-48);
        }
        if(a%3==0){
            puts("Yes");
            a=0;
        }
        else {
            puts("No");
            a=0;
        }
    }
}