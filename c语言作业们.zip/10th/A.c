#include <stdio.h>
int main() {
    int a;
    int b, c;
    int matrix[105][105];
    int flag = 1;
    scanf("%d", &a);
    for (int i = 0; i < a; i++) {
        scanf("%d %d", &b, &c);
        for (int j = 0; j < b; j++) {
            for (int k = 0; k < c; k++) {
                scanf("%d", &matrix[j][k]);
            }
        }
        for (int j = 0; j < c; j++) {
            for (int k = 0; k < b; k++) {
                if (flag) {
                    flag = 0;
                    printf("%d", matrix[k][j]);
                } else
                    printf(" %d", matrix[k][j]);
            }
            flag = 1;
            puts("");
        }
        puts("");
    }
}