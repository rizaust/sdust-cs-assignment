#include <stdio.h>
#include<string.h>
#include<stdlib.h>
int main() {
    char a[100];
    scanf("%s", a);
    int b;
    b = strlen(a);
    for (int i = b - 1; i >= 0; i--) {
        printf("%c", a[i]);
    }
}