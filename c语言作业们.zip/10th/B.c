#include <stdio.h>
int main() {
    int a, b, c, d;
    int matrixa[105][105];
    int matrixb[105][105];
    int flag = 1;
    int flag1 = 1;
    while (~scanf("%d %d", &a, &b), a != 0) {
        if (a == 0) return 0;
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < b; j++) {
                scanf("%d", &matrixa[i][j]);
            }
        }
        if (scanf("%d %d", &c, &d), c != 0) {
            for (int i = 0; i < c; i++) {
                for (int j = 0; j < d; j++) {
                    scanf("%d", &matrixb[i][j]);
                }
            }
            if (flag1) {
                printf("");
                flag1 = 0;
            } else
                puts("");
            if (a == c && b == d) {
                for (int i = 0; i < c; i++) {
                    for (int j = 0; j < d; j++) {
                        matrixa[i][j] = matrixa[i][j] + matrixb[i][j];
                    }
                }

                for (int i = 0; i < c; i++) {
                    for (int j = 0; j < d; j++) {
                        if (flag) {
                            flag = 0;
                            printf("%d", matrixa[i][j]);
                        } else
                            printf(" %d", matrixa[i][j]);
                    }
                    flag = 1;
                    puts("");
                }
            } else
                printf("Not satisfied the definition of matrix addition!");

        } else
            return 0;
    }
}