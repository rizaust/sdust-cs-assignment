#include<stdio.h>
int main(){
    int a;
    long long ans=0;
    long long tmp=1;
    scanf("%d",&a);
    if(a>=13){
        puts("overflow");
    }
    else{
        for(int i=0;i<a;i++){
            ans=ans+tmp;
            tmp*=i+2;
        }
        printf("%lld",ans);
    }
}