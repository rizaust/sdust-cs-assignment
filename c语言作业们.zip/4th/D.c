#include <stdio.h>
int main() {
    int a, b;
    int flag = 1;
    while (~scanf("%d %d", &a, &b)) {
        if (flag) {
            printf("%d", a + b);
            flag = !flag;
        } else
            printf("\n\n%d", a + b);
    }
}