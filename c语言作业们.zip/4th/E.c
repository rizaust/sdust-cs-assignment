#include <stdio.h>
int main() {
    double a, b, c;
    char d;
    scanf("%c", &d);
    for (int i = 0; i < 4; i++) {
        getchar();
    }
    if (d == 'F') {
        puts("   F  ->    C");
        scanf("%lf %lf %lf", &a, &b, &c);
        for (double i = a; i <= b+0.001; i += c) {
            printf("%5.1lf -> ", i);
            printf("%5.1lf\n", (i - 32) * 5 / 9);
        }
    }
    if (d == 'C') {
        puts("   C  ->    F");
        scanf("%lf %lf %lf", &a, &b, &c);
        for (double i = a; i <= b+0.001; i += c) {
            printf("%5.1lf -> ", i);
            printf("%5.1lf\n", i*9/5+32);
        }
    }
}