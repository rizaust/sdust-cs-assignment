#include <stdio.h>
int main() {
    scanf("COCK,HEN,CHICK,MONEY,CHICKS\n");
    int a, b, c, d, e, f;
    while (~scanf("%d,%d,%d/%d,%d,%d", &a, &b, &c, &d, &e, &f)) {
        for(int i=0;i<f;i++){
            for(int j=0;j<f;j++){
                int k=f-i-k;
                
            }
        }
    }
}