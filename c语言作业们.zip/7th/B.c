#include <stdio.h>
unsigned long long hanoi(int n) {
    if (n == 1)
        return 1;
    else
        return 2 * hanoi(n - 1) + 1;
}
int main() {
    int a;
    scanf("%d",&a);
    printf("%llu", hanoi(a));
}