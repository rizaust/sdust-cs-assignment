#include <stdio.h>
int digits(int n) {
    if (n < 0) n = -n;
    n=n/10;
    if (n==0) return 1;
    return digits(n)+1;
    
}
int main() {
    int num;
    scanf("%d", &num);
    printf("%d\n", digits(num));
}