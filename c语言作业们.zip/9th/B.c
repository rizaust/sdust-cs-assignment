#include <stdio.h>
int main() {
    int a;
    int b[100005];
    int found = 1;
    scanf("%d", &a);
    for (int i = 0; i < a; i++) {
        scanf("%d", &b[i]);
    }
    int c;
    while (~scanf("%d", &c)) {
        for (int i = 0; i < a; i++) {
            if (b[i] == c) {
                printf("%d\n", i + 1);
                found = 0;
                break;
            }
        }
        if (found) puts("NOT FOUND");
        found = 1;
    }
}
