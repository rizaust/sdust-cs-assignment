#include <stdio.h>
int main() {
    int a;
    int b[100005];
    scanf("%d", &a);
    for (int i = 0; i < a; i++) {
        scanf("%d", &b[i]);
    }
    int c;
    while (~scanf("%d", &c)) {
        if (c <= a&&c>0) {
            printf("%d\n", b[c - 1]);
        } else
            puts("OUT OF RANGE");
    }
}
