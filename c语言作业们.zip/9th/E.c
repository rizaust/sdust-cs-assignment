
#include <stdio.h>
int main() {
    int a;
    int b[100005];
    int found = 1;
    int flag = 1;
    scanf("%d", &a);
    for (int i = 0; i < a; i++) {
        scanf("%d", &b[i]);
    }
    int c;
    while (~scanf("%d", &c)) {
        for (int i = 0; i < a; i++) {
            if (b[i] == c) {
                if (flag) {
                    printf("%d", i + 1);
                    flag = 0;
                }
                else printf(" %d", i + 1);
                found = 0;
            }
        }
        if (found) printf("NOT FOUND");
        puts("");
        found = 1;
        flag = 1;
    }
}
