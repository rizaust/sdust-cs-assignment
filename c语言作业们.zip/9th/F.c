
#include <stdio.h>
int max(int a, int b) {
    if (a > b) {
        return a;
    } else
        return b;
}
int min(int a, int b) {
    if (a < b)
        return a;
    else
        return b;
}
int main() {
    int a;
    int b[100005];
    int maxn;
    int minn;
    int flag = 1;
    int flag1 = 1;
    scanf("%d", &a);
    for (int i = 1; i <= a; i++) {
        scanf("%d", &b[i]);
    }
    int c;
    int d;
    while (~scanf("%d", &c)) {
        scanf("%d", &d);
        maxn = min(max(c, d), a);
        minn = max(1, min(c, d));
        if (maxn < minn) {
            printf("OUT OF RANGE");
        } else {
            for (int i = minn; i <= maxn; i++) {
                if (flag1) {
                    printf("%d", b[i]);
                    flag1 = 0;
                } else
                    printf(" %d", b[i]);
            }
        }
        puts("");
        flag=1;
        flag1=1;
    }
}
