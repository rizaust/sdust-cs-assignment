#include <stdio.h>
int gcd(int a, int b) {
    if (a % b == 0) return b; //过于简洁，牛批。
    return gcd(b, a % b);
}
int main() {
    int a, b;
    while (~scanf("%d %d", &a, &b)) {
        if(b==0){
            int c;
            c=a;
            a=b;
            b=c;
        }
        printf("%d ", gcd(a,b));
        printf("%d\n", a * b / gcd(a, b));
    }
}
