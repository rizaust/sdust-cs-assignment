#include <stdio.h>

int main() {
    int c[105] = {0};
    c[1] = 1;
    c[0] = 1;
    // for (int i = 2; i <= sqrt(100); i++) {
    //     if (c[i] == 0) {
    //         for (int j = i * i; j <= 101; j += i) {
    //             c[j] = 1;
    //         }
    //     }
    // }
    for (int i = 2; i < sqrt(100); i++) {
        if (c[i] == 0) {
            for (int j = i * i; j <= 100; j += i) {
                c[j] = 1;
            }
        }
    }
    // for (int i = 2; i < 100; i++) {
    //     if (c[i] == 0) {
    //         for (int j = 2; j * i <= 100; j++) {
    //             c[i * j] = 1;
    //         } 
    //     }
    // }
    printf("=====\n");
    int a, b;
    scanf("%d %d", &a, &b);
    for (int i = b; i >= a; i--) {
        if (c[i] == 0) {
            printf("%d\n", i);
        }
    }
    printf("=====");
}
