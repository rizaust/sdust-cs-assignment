#include <stdio.h>
int max(int a, int b) {
    if (a > b)
        return a;
    else
        return b;
}
int main() {
    int a[1005] = {0};
    int b[1005] = {0};
    int flag = 1;
    int flag1 = 1;
    int c, d;
    while (~scanf("%d", &c)) {
        if (flag1) {
            flag1 = 0;
        } else
            puts("");
        for (int i = 0; i < c; i++) {
            scanf("%d", &a[i]);
        }
        if (~scanf("%d", &d)) {
            for (int i = 0; i < d; i++) {
                scanf("%d", &b[i]);
            }
        } else
            d = 0;
        for (int i = 0; i < 1005; i++) {
            a[i] = a[i] + b[i];
        }
        for (int i = 0; i < max(c, d); i++) {
            if (flag) {
                printf("%d", a[i]);
                flag = 0;
            } else
                printf(" %d", a[i]);
        }
        for (int i = 0; i < 1005; i++) {
            a[i] = 0;
        }
        for (int i = 0; i < 1005; i++) {
            b[i] = 0;
        }
        flag = 1;
        
    }
}

