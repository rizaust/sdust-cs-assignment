#include <stdio.h>
#include <string.h>
int max(int a, int b) {
    if (a > b)
        return a;
    else
        return b;
}
int main() {
    int a[1005] = {0};
    int b[1005] = {0};
    int c, d, e;
    int flag = 1;
    scanf("%d", &c);
    scanf("%d", &d);
    for (int i = 0; i < d; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < c - 1; i++) {
        scanf("%d", &e);
        for (int j = 0; j < e; j++) {
            scanf("%d", &b[j]);
        }
        for (int j = 0; j < max(d, e); j++) {
            a[j] = a[j] + b[j];
        }
        for (int j = 0; j < max(d, e); j++) {
            if (flag) {
                printf("%d", a[j]);
                flag = 0;
            } else {
                printf(" %d", a[j]);
            }
        }
        for (int j = 0; j < max(d, e); j++) {
            a[j] = b[j];
        }
        memset(b, 0, sizeof(b));
        d = e;
        puts("");
        flag=1;
    }
    for (int j = 0; j < max(d, e); j++) {
        if(flag){
            printf("%d",a[j]);
            flag=0;
        }
        else printf(" %d", a[j]);
    }
}
